"""第6课 - 可运行的项目管理看板。安装requirements后使用 streamlit run app.py。"""
from __future__ import annotations
import json
import os
from datetime import date
from pathlib import Path
import streamlit as st
from pm_core import load_csv_dir, load_xlsx, analyze, report_markdown, ai_payload

st.set_page_config(page_title="新能源汽车项目管理AI助手", page_icon="🚗", layout="wide")
st.title("🚗 新能源汽车研发项目管理 AI 助手")
st.caption("第6课作品集｜教学模拟数据｜Python计算 + 可选AI解读 + 人工审批")
st.warning("本项目的205件目标源自公开汽车线束案例，其余BOM、日期、问题及成本均为自行设计的模拟数据；请勿作为真实企业经历。")

with st.sidebar:
    st.header("项目数据")
    mode=st.radio("数据来源", ["教学案例CSV","上传第5课Excel"], index=0)
    uploaded=None
    if mode=="上传第5课Excel":
        uploaded=st.file_uploader("上传工作簿（.xlsx）", type=["xlsx"], help="需要第2课至第5课的6张对应工作表")
    as_of=st.date_input("项目统计日期（情景回放）",value=date(2026,9,21))
    st.caption("只改变统计日期不会改变业务数据；逾期数量属于假设回放。")
    st.divider()
    st.caption("AI分析需要用户自行提供API密钥，会产生相应API费用。默认只进行本地规则计算。")

try:
    if mode=="上传第5课Excel":
        if not uploaded:
            st.info("请上传第5课工作簿，或切换到教学案例CSV模式。")
            st.stop()
        dataset=load_xlsx(uploaded.getvalue())
    else:
        dataset=load_csv_dir(Path(__file__).parent/"data")
    result=analyze(dataset,as_of)
except Exception as exc:
    st.error(f"数据加载失败：{exc}")
    st.stop()

s=result["stats"]
a,b,c,d,e,f=st.columns(6)
a.metric("任务完成率",f"{s['task_complete_rate']:.1%}",f"{s['task_done']}/{s['task_total']}项",delta_color="off")
b.metric("预测延期任务",f"{s['forecast_delays']}项")
c.metric("物料配套上限",f"{s['kit_capacity']}件",f"目标{s['target_units']}件",delta_color="off")
d.metric("开放Issue",f"{s['open_issues']}条",f"高优先级{s['high_priority_open_issues']}条",delta_color="off")
e.metric("未批准CR",f"{s['unapproved_cr']}条")
f.metric("累计人工成本偏差",f"¥{s['cost_variance']:+,.0f}",help="实际累计-截至本期的计划累计；不等于项目最终超支")

st.markdown("### 关键异常与管理建议")
if s["overdue_issues"] or s["overdue_actions"]:
    st.error(f"在{as_of.isoformat()}的情景回放下，回复逾期Issue {s['overdue_issues']}条、逾期会议行动项{s['overdue_actions']}条。请核查原始状态是否已经更新。")
if result["shortages"]:
    st.warning(f"{s['material_shortages']}类必需物料存在质量放行缺口；当前齐套能力为{s['kit_capacity']}件。到货不等于检验放行。")
if result["invalid_approval"]:
    st.error("发现已批准CR但职能评审不全，请核查数据与审批链。")

x1,x2,x3,x4=st.tabs(["零部件与Issue","WBS与行动项","CR与成本","周报与AI解读"])
with x1:
    st.subheader("物料缺口（由需求与质量放行数量重新计算）")
    st.dataframe([{"编号":x["code"],"物料":x["name"],"需求量":int(x["needed"]),"到货量":int(float(x["arrived_qty"])),"放行量":int(float(x["released_qty"])),"放行缺口":int(x["shortage"]),"可配套件数":x["supported"],"BOM版本":x["bom_revision"]} for x in result["materials"]],hide_index=True,use_container_width=True)
    st.subheader("开放Issue")
    st.dataframe([{"编号":x["issue_id"],"优先级":x["priority"],"问题":x["description"],"牵头岗位":x["owner"],"回复截止":x["response_due"],"状态":x["status"]} for x in result["open_issues"]],hide_index=True,use_container_width=True)
with x2:
    st.subheader("所有WBS任务")
    st.dataframe([{"编号":x["id"],"任务":x["task"],"负责人":x["owner"],"计划完成":x["plan_end"],"预测完成":x["forecast_end"],"状态":x["status"]} for x in dataset["tasks"]],hide_index=True,use_container_width=True)
    st.subheader("按情景日期计算的逾期行动项")
    st.dataframe([{"行动号":x["action_id"],"动作":x["action"],"截止日期":x["due_date"],"责任岗位":x["owner"],"状态":x["status"]} for x in result["overdue_actions"]],hide_index=True,use_container_width=True)
with x3:
    st.subheader("变更申请：未经授权不得实施")
    st.dataframe([{"CR":x["cr_id"],"主题":x["title"],"研发":x["r_and_d_review"],"质量":x["quality_review"],"制造":x["manufacture_review"],"采购":x["procurement_review"],"批准状态":x["approval"]} for x in dataset["changes"]],hide_index=True,use_container_width=True)
    st.subheader("工时和人工成本（同一统计口径）")
    p,q,r=st.columns(3)
    p.metric("截至本期计划工时",f"{s['plan_hours']:.0f}h")
    q.metric("实际累计工时",f"{s['actual_hours']:.0f}h")
    r.metric("工时偏差",f"{s['hours_variance']:+.0f}h")
    st.dataframe([{"工作包":x["work_pkg"],"同期计划工时":x["planned_hours_to_date"],"实际累计工时":x["actual_hours_to_date"],"小时费率":x["rate"]} for x in dataset["costs"]],hide_index=True,use_container_width=True)
with x4:
    md=report_markdown(result)
    st.markdown(md)
    st.download_button("⬇️ 下载规则生成周报（Markdown）",data=md.encode("utf-8"),file_name="项目管理周报_模拟.md",mime="text/markdown")
    st.divider()
    st.subheader("可选：调用大模型辅助分析")
    st.caption("仅发送聚合指标和选定异常，不发送整份Excel。请勿上传未经授权的真实企业敏感数据。")
    key=st.text_input("API Key（不会写入项目文件）",value="",type="password",placeholder="也可设置OPENAI_API_KEY环境变量")
    model=st.text_input("模型ID（可按你可用的API模型修改）",value="gpt-6-luna")
    if st.button("生成AI风险解读",type="primary"):
        token=key or os.getenv("OPENAI_API_KEY","")
        if not token:
            st.error("请填写API Key或设置环境变量；无需API也可下载规则周报。")
        else:
            try:
                from openai import OpenAI
                client=OpenAI(api_key=token,timeout=30,max_retries=1)
                response=client.responses.create(
                    model=model,
                    instructions=("你是汽车项目管理风险分析助手。只能使用输入的已计算指标与问题。"
                                  "用中文给出：①一段高管摘要；②不超过4项风险（须引用提供的编号）；"
                                  "③部门待核查动作；④需要有权人员决定的事项；⑤信息不足与口径限制。"
                                  "禁止编造实际结果、批准状态、供应商答复、工期或量化收益；"
                                  "不得自行批准任何CR或将预测写成事实。输出只是待人工复核的草稿。"),
                    input=json.dumps(ai_payload(result),ensure_ascii=False),
                )
                st.markdown("#### AI分析草稿（请人工复核）")
                st.markdown(response.output_text or "模型未返回文本，请检查响应。")
            except Exception as exc:
                st.error(f"API请求失败：{exc.__class__.__name__}，请检查密钥、模型权限、网络和额度。")

st.divider()
st.caption("作品集边界：案例源于公开的汽车线束项目研究；所有具体部门、工时、日期、物料清单与处理记录均为模拟。")
