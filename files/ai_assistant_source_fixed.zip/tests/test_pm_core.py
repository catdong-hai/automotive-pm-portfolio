import sys
import unittest
from datetime import date
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pm_core import load_csv_dir,load_xlsx,analyze,report_markdown,ai_payload
ROOT=Path(__file__).resolve().parents[1]

class PMTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=load_csv_dir(ROOT/'data')
        cls.r=analyze(cls.data,date(2026,9,21))
    def test_metrics(self):
        s=self.r['stats']
        self.assertEqual(s['task_total'],9)
        self.assertEqual(s['task_done'],4)
        self.assertEqual(s['forecast_delays'],5)
        self.assertEqual(s['kit_capacity'],180)
        self.assertEqual(s['material_ready'],4)
        self.assertEqual(s['open_issues'],5)
        self.assertEqual(s['unapproved_cr'],3)
        self.assertEqual(s['actual_hours'],127)
        self.assertEqual(s['plan_hours'],112)
        self.assertEqual(s['cost_variance'],1455)
        self.assertEqual(s['overdue_issues'],0)
    def test_replay_overdue(self):
        r=analyze(self.data,date(2026,9,24))
        self.assertEqual(r['stats']['overdue_issues'],5)
        self.assertEqual(r['stats']['overdue_actions'],7)
    def test_report(self):
        text=report_markdown(self.r)
        self.assertIn('180件',text)
        self.assertIn('未获批准CR',text)
        self.assertEqual(ai_payload(self.r)['已核算指标']['task_done'],4)
    def test_xlsx_import(self):
        original=ROOT/'第5课原始项目工作簿.xlsx'
        if not original.exists(): self.skipTest('未附带原始Excel')
        data=load_xlsx(original.read_bytes())
        r=analyze(data,date(2026,9,21))
        self.assertEqual(r['stats']['kit_capacity'],180)
        self.assertEqual(r['stats']['cost_variance'],1455)
        self.assertEqual(r['stats']['task_done'],4)

if __name__=='__main__': unittest.main()
