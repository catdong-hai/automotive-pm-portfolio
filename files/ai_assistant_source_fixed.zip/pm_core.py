"""电池线束试制项目管理核心逻辑。所有指标均由规则计算，大模型不参与数字计算。"""
from __future__ import annotations

import csv
import io
import json
import math
import re
import zipfile
from datetime import date, timedelta
from pathlib import Path
from xml.etree import ElementTree as ET

# 案例数据由前五课模拟工作簿的6张工作表提取，未包含真实企业内部数据。
FIELDS = {
    "tasks": ("第2课_线束WBS", 3, 11, ["id","work_package","task","owner","predecessors","plan_start","plan_end","forecast_end","actual_end","status","slip_days","risk","next_action"]),
    "materials": ("第3课_齐套台账", 6, 13, ["code","name","usage_per_unit","target_units","required_qty","arrived_qty","released_qty","promised_qty","promise_date","needed_date","gap","promised_gap","supported_units","risk","owner","next_action","bom_revision"]),
    "issues": ("第4课_Issue管理", 5, 10, ["issue_id","issue_type","description","milestone","priority","owner","collaborators","status","raised_date","response_due","overdue_hint","next_action","escalation_trigger","close_evidence","linked_cr","updated_at","source_type"]),
    "changes": ("第4课_CR变更评估", 5, 8, ["cr_id","title","trigger","baseline","proposed","schedule_effect","cost_effect","r_and_d_review","quality_review","manufacture_review","procurement_review","approval","implementation","decision_due","linked_issues","evidence","notes"]),
    "actions": ("第4课_会议行动项", 5, 12, ["meeting_date","topic","decision","action_id","action","owner","collaborators","status","due_date","overdue_hint","evidence","linked_ids","needs_decision"]),
    "costs": ("第5课_工时成本", 5, 10, ["work_pkg","total_budget_hours","planned_hours_to_date","actual_hours_to_date","hours_variance","rate","plan_cost","actual_cost","variance","notes"]),
}
DATE_FIELDS = {"plan_start","plan_end","forecast_end","actual_end","promise_date","needed_date","raised_date","response_due","updated_at","decision_due","meeting_date","due_date"}
NUM_FIELDS = {"slip_days","usage_per_unit","target_units","required_qty","arrived_qty","released_qty","promised_qty","gap","promised_gap","supported_units","total_budget_hours","planned_hours_to_date","actual_hours_to_date","hours_variance","rate","plan_cost","actual_cost","variance"}
MAIN = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
PKG = "http://schemas.openxmlformats.org/package/2006/relationships"


def _date_from_excel(n):
    return (date(1899, 12, 30) + timedelta(days=int(float(n)))).isoformat()


def _clean_value(val, field):
    if val is None: return ""
    if isinstance(val, str): val = val.strip()
    if field in DATE_FIELDS:
        if val == "": return ""
        if isinstance(val, (int,float)) or (isinstance(val,str) and re.fullmatch(r"\d+(\.0+)?",val)):
            return _date_from_excel(val)
        return str(val)[:10]
    if field in NUM_FIELDS:
        try: return float(val) if val != "" else 0.0
        except (ValueError, TypeError): return 0.0
    return str(val)


def load_csv_dir(folder: str | Path):
    folder = Path(folder)
    data = {}
    for name, (_, _, _, fields) in FIELDS.items():
        with (folder / f"{name}.csv").open(encoding="utf-8-sig", newline="") as f:
            records=list(csv.DictReader(f))
        if not records: raise ValueError(f"{name}.csv为空")
        missing=set(fields).difference(records[0])
        if missing: raise ValueError(f"{name}.csv缺少列：{sorted(missing)}")
        data[name]=[{key:_clean_value(row.get(key),key) for key in fields} for row in records]
    return data


def _xlsx_sheet_tables(xlsx_bytes: bytes):
    """只读xlsx中的单元格原始值；不执行公式，不运行宏。"""
    if len(xlsx_bytes)>20_000_000: raise ValueError("文件大于20MB，请精简后再上传")
    z=zipfile.ZipFile(io.BytesIO(xlsx_bytes))
    names=set(z.namelist())
    if "xl/workbook.xml" not in names: raise ValueError("不是有效的.xlsx工作簿")
    shared=[]
    if "xl/sharedStrings.xml" in names:
        root=ET.fromstring(z.read("xl/sharedStrings.xml"))
        for si in root.findall(f"{{{MAIN}}}si"):
            shared.append("".join((x.text or "") for x in si.iter(f"{{{MAIN}}}t")))
    book=ET.fromstring(z.read("xl/workbook.xml"))
    rels=ET.fromstring(z.read("xl/_rels/workbook.xml.rels"))
    mapping={r.get("Id"):r.get("Target") for r in rels.findall(f"{{{PKG}}}Relationship")}
    result={}
    for sh in book.findall(f".//{{{MAIN}}}sheet"):
        rid=sh.get(f"{{{REL}}}id")
        target=mapping.get(rid, "")
        if target.startswith("/"): target=target.lstrip("/")
        elif not target.startswith("xl/"): target="xl/"+target
        if target not in names: continue
        root=ET.fromstring(z.read(target))
        rows={}
        for row in root.findall(f".//{{{MAIN}}}sheetData/{{{MAIN}}}row"):
            rn=int(row.get("r", "0"))
            cells={}
            for cell in row.findall(f"{{{MAIN}}}c"):
                ref=cell.get("r","")
                letters=re.match(r"[A-Z]+",ref)
                if not letters: continue
                index=0
                for ch in letters.group(0): index=index*26+ord(ch)-ord('A')+1
                index-=1
                typ=cell.get("t")
                v=cell.find(f"{{{MAIN}}}v")
                if typ=="inlineStr":
                    x=cell.find(f"{{{MAIN}}}is")
                    value="".join(y.text or "" for y in x.iter(f"{{{MAIN}}}t")) if x is not None else ""
                elif v is None or v.text is None: value=""
                elif typ=="s": value=shared[int(v.text)]
                elif typ in {"str", "e", "b"}: value=v.text
                else:
                    try: value=float(v.text)
                    except ValueError: value=v.text
                cells[index]=value
            rows[rn]=cells
        result[sh.get("name")]=rows
    return result


def load_xlsx(xlsx_bytes: bytes):
    tables=_xlsx_sheet_tables(xlsx_bytes)
    required_sheets=[info[0] for info in FIELDS.values()]
    missing=[name for name in required_sheets if name not in tables]
    if missing: raise ValueError("不包含第2—5课全部6张必要工作表："+"、".join(missing))
    data={}
    for name,(sheet_name,start,end,fields) in FIELDS.items():
        rows=tables[sheet_name]
        result=[]
        for rownum in range(start,end+1):
            row=rows.get(rownum,{})
            if not row.get(0): continue
            result.append({field:_clean_value(row.get(j),field) for j,field in enumerate(fields)})
        if not result: raise ValueError(f"工作表 {sheet_name} 缺少有效数据")
        data[name]=result
    return data


def _num(row, key):
    try: return float(row.get(key) or 0)
    except (ValueError, TypeError): return 0.0


def _parsed_date(value):
    try: return date.fromisoformat(str(value)[:10]) if value else None
    except (ValueError,TypeError): return None


def _is_closed(row):
    return str(row.get("status", "")).strip() in {"已关闭", "已完成", "关闭", "完成"}


def analyze(data, as_of: date):
    tasks=data["tasks"]
    materials=data["materials"]
    issues=data["issues"]
    changes=data["changes"]
    actions=data["actions"]
    costs=data["costs"]
    done=[r for r in tasks if _is_closed(r)]
    delayed=[r for r in tasks if not _is_closed(r) and _parsed_date(r.get("plan_end")) and _parsed_date(r.get("forecast_end")) and _parsed_date(r["forecast_end"])>_parsed_date(r["plan_end"])]
    issues_open=[r for r in issues if not _is_closed(r)]
    issues_overdue=[r for r in issues_open if _parsed_date(r.get("response_due")) and _parsed_date(r["response_due"])<as_of]
    actions_open=[r for r in actions if not _is_closed(r)]
    actions_overdue=[r for r in actions_open if _parsed_date(r.get("due_date")) and _parsed_date(r["due_date"])<as_of]
    unapproved=[r for r in changes if str(r.get("approval"))!="已批准"]
    invalid_approval=[r for r in changes if r.get("approval")=="已批准" and not all(r.get(k)=="通过" for k in ("r_and_d_review","quality_review","manufacture_review","procurement_review"))]

    mat_status=[]
    for r in materials:
        usage=_num(r,"usage_per_unit")
        target=int(_num(r,"target_units"))
        required=usage*target
        arrived=_num(r,"arrived_qty")
        released=_num(r,"released_qty")
        supported=min(target, math.floor(released/usage)) if usage>0 else 0
        mat_status.append({**r,"needed":required,"shortage":max(0,required-released),"supported":supported,"quality_anomaly":released>arrived or usage<=0})
    kit_cap=min((m["supported"] for m in mat_status),default=0)
    shortages=[m for m in mat_status if m["shortage"]>0]
    ready=sum(m["shortage"]<=0 for m in mat_status)

    plan_hours=sum(_num(r,"planned_hours_to_date") for r in costs)
    actual_hours=sum(_num(r,"actual_hours_to_date") for r in costs)
    plan_cost=sum(_num(r,"planned_hours_to_date")*_num(r,"rate") for r in costs)
    actual_cost=sum(_num(r,"actual_hours_to_date")*_num(r,"rate") for r in costs)
    total_budget=sum(_num(r,"total_budget_hours") for r in costs)
    stats={"as_of":as_of.isoformat(),"task_total":len(tasks),"task_done":len(done),"task_complete_rate":len(done)/len(tasks) if tasks else 0,
        "forecast_delays":len(delayed),"target_units":int(_num(materials[0],"target_units")) if materials else 0,
        "material_total":len(materials),"material_ready":ready,"kit_capacity":kit_cap,"material_shortages":len(shortages),
        "open_issues":len(issues_open),"overdue_issues":len(issues_overdue),"high_priority_open_issues":sum(x.get("priority")=="高" for x in issues_open),
        "unapproved_cr":len(unapproved),"approved_without_all_reviews":len(invalid_approval),
        "overdue_actions":len(actions_overdue),"total_budget_hours":total_budget,
        "plan_hours":plan_hours,"actual_hours":actual_hours,"hours_variance":actual_hours-plan_hours,
        "plan_cost":plan_cost,"actual_cost":actual_cost,"cost_variance":actual_cost-plan_cost}
    return {"stats":stats,"delayed_tasks":delayed,"materials":mat_status,"shortages":shortages,"open_issues":issues_open,
            "overdue_issues":issues_overdue,"unapproved_changes":unapproved,"overdue_actions":actions_overdue,"invalid_approval":invalid_approval}


def report_markdown(result):
    s=result["stats"]
    lines=["# 新能源汽车电池线束试制项目周报（模拟）",f"统计快照：{s['as_of']}｜数据性质：个人教学模拟，非真实企业项目", "",
      "## 1. 进度和资源概览",
      f"- WBS任务：已完成 **{s['task_done']}/{s['task_total']}项**（{s['task_complete_rate']:.1%}）；预测晚于计划的未完成任务 **{s['forecast_delays']}项**。",
      f"- 关键物料：已齐套 **{s['material_ready']}/{s['material_total']}类**，当前最多可为 **{s['kit_capacity']}件**线束提供完整物料（目标{s['target_units']}件，不代表实际产量）。",
      f"- Issue：开放 **{s['open_issues']}条**，其中高优先级 **{s['high_priority_open_issues']}条**；按本次模拟日期计算，回复逾期 **{s['overdue_issues']}条**。",
      f"- 变更：未获批准CR **{s['unapproved_cr']}条**；会议行动项按本次模拟日期逾期 **{s['overdue_actions']}条**。",
      f"- 人工投入：实际累计 **{s['actual_hours']:.0f}小时**，较同期计划 **{s['hours_variance']:+.0f}小时**；人工成本偏差 **{s['cost_variance']:+,.0f}元**（不等于全项目最终超支）。",
      "", "## 2. 需要关注的问题"]
    for x in result["shortages"][:5]:
        lines.append(f"- **{x['code']} {x['name']}**：质量放行缺口{x['shortage']:.0f}个，当前可配套{x['supported']}件；责任部门：{x['owner']}。")
    for x in result["overdue_issues"][:5]:
        lines.append(f"- **{x['issue_id']}**：回复截止{x['response_due']}，仍为“{x['status']}”；需核实最新回复与处理证据。")
    lines += ["", "## 3. 决策与行动建议",
       "- 采购、研发、质量和制造部门核对关键物料交期、BOM版本、来料放行及试装依赖。",
       "- 对影响9月24日试装的事项组织有授权人员开展Go/No-Go评审；未经批准不得修改正式计划基线或实施新版本。",
       "- 依据Issue截止时间催办，并将供应商书面回复、检验记录、决议纪要作为关闭证据。",
       "", "## 4. 口径与限制",
       "- 改动统计日期但不改状态时，逾期结果只是情景回放，不代表历史真实记录。",
       "- 物料配套量是由已放行数量和单件耗用推算的理论上限，还依赖工艺、版本和其他批准条件。",
       "- 本周报为规则生成的初稿，必须由项目负责人复核后才能用于真实业务汇报。"]
    return "\n".join(lines)


def ai_payload(result):
    """仅汇总项目指标与非个人敏感的关键异常，不上传整份原始文件。"""
    s=result["stats"]
    return {
        "数据性质":"个人模拟项目，非真实企业运营数据",
        "统计日期":s["as_of"],
        "已核算指标":s,
        "物料短缺":[{"编号":x["code"],"名称":x["name"],"放行缺口":x["shortage"],"责任部门":x["owner"]} for x in result["shortages"]],
        "开放高风险Issue":[{"编号":x["issue_id"],"描述":x["description"],"状态":x["status"],"下一步":x["next_action"]} for x in result["open_issues"] if x["priority"]=="高"],
        "待批准CR":[{"编号":x["cr_id"],"主题":x["title"],"审批":x["approval"]} for x in result["unapproved_changes"]],
        "边界":"不得生成未经提供的供应商答复、审批记录、实际产量或真实性能；不得代替项目经理批准变更。"
    }
