# 第6课：新能源汽车项目管理 AI 助手（教学版）

## 项目定位
- 这是**个人模拟项目**，不是蔚来或其他汽车企业的真实项目文件。
- 参考公开汽车行业电池线束开发的小批量制造案例（205件），具体日期、BOM、物料数量、Issue、CR、费率和工时为教学设定。
- 原型参考文献：Sustainability 2020, 12(21), 9245；https://doi.org/10.3390/su12219245

## 目录说明
- `app.py`：Streamlit项目管理看板，默认读取CSV；可上传第5课工作簿。
- `pm_core.py`：读取、统计与生成周报的核心代码；xlsx由Python标准库只读解析，不执行宏。
- `data/*.csv`：由前五课Excel教学模拟文件中的六张工作表整理的示例数据。
- `第5课原始项目工作簿.xlsx`：此前练习的完整Excel工作簿。
- `tests/test_pm_core.py`：核对关键数字的自动化单元测试。
- `示范项目周报.md`：规则引擎生成的可审阅报告。

## Windows操作（PowerShell）
1. 解压文件夹，用VS Code打开文件夹。
2. 在终端输入：

```powershell
python -m venv .venv
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python -m unittest discover -s tests -v
streamlit run app.py
```

如果PowerShell禁止执行脚本，可使用命令提示符CMD，执行 `.venv\Scripts\activate.bat`；或直接运行 `.venv\Scripts\python.exe -m streamlit run app.py`。

3. 浏览器一般自动打开本地网页，地址通常为 http://localhost:8501 。
4. 使用默认的CSV教学案例即可查看看板，也可以切换到“上传第5课Excel”并选择本文件夹内的工作簿。
5. 更改统计日期为2026-09-24，会看到逾期Issue与行动项增加。**注意这只是把同一批未更新状态带入新的假设日期。**
6. “规则周报”无需API；“AI分析”是可选功能，调用前须提供你自己的OpenAI API Key，并会产生相应费用。

## 你要掌握的三条计算逻辑

- 预测延期任务：未完成，且 `forecast_end > plan_end`。
- 物料理论配套上限：对每个必需物料计算 `floor(released_qty / usage_per_unit)`，再取最小值，且不能超过目标件数。
- 成本偏差：同一统计期 `实际累计工时×费率－计划累计工时×费率`，不是最终预算差异。

## 开发边界

- 未经授权不得上传企业内部敏感台账或个人信息到第三方模型API。
- AI仅接收聚合指标和选定异常，不接收整个Excel文件；大模型不能替代项目经理批准CR。
- 不得将示例结果描述为真实企业绩效，不得将模型输出作为检验放行或质量安全的充分依据。
- 这是教学原型：暂不包括企业权限控制、审计日志、并发修改、成本会计核算、ERP/PLM/MES集成和生产部署测试。

## 可在面试中真实描述什么？

亲自运行、修改并解释系统后，可以说明：
“我基于公开汽车零部件开发案例，独立完成了教学模拟项目的项目台账整合、WBS延期和物料齐套计算、Issue/CR风险看板与自动周报，并将大模型接口作为可选的辅助文字分析模块；计算和审批都保留确定性规则与人工复核。”

请勿说自己在真实车企上线过该系统。
